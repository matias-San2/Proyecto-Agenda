// aws/src/handlers/chaos/engine.js
const { DynamoDBClient, ListTablesCommand } = require('@aws-sdk/client-dynamodb');
const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-1' });

exports.handler = async (event) => {
  const experiment = event?.queryStringParameters?.type || 'random';
  const delay = Math.floor(Math.random() * 4000) + 500; // 0.5 - 4.5s

  console.log(`⚙️ Chaos experiment triggered: ${experiment}`);

  try {
    // 1️⃣ Simular latencia aleatoria
    await new Promise((resolve) => setTimeout(resolve, delay));

    // 2️⃣ Simular fallo interno con probabilidad
    if (experiment === 'failure' || (experiment === 'random' && Math.random() < 0.25)) {
      throw new Error(`ChaosEngine simulated internal failure after ${delay}ms`);
    }

    // 3️⃣ Simular fallo de DynamoDB
    if (experiment === 'dynamodb' || (experiment === 'random' && Math.random() < 0.15)) {
      console.log('💥 Simulando error de conexión con DynamoDB...');
      throw new Error('Simulated DynamoDB failure');
    }

    // Verificar conexión real si no hubo caos
    const command = new ListTablesCommand({});
    await client.send(command);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'healthy',
        delay: `${delay}ms`,
        dynamodb: 'connected',
        chaosMode: experiment,
        timestamp: new Date().toISOString(),
      }),
    };
  } catch (error) {
    console.error('🔥 Chaos experiment failed:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'failed',
        error: error.message,
        delay: `${delay}ms`,
        chaosMode: experiment,
        timestamp: new Date().toISOString(),
      }),
    };
  }
};
